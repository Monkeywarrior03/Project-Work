package it.band.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import it.band.model.Product;

public interface ProductDao extends CrudRepository<Product, Integer>{
	
	@Query (value = "SELECT MAX from products.id", nativeQuery = true)
	public int getHighestId();
}