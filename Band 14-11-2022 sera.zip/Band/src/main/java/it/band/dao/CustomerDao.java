package it.band.dao;

import org.springframework.data.repository.CrudRepository;

import it.band.model.Customer;

public interface CustomerDao extends CrudRepository<Customer, Integer>{

}
