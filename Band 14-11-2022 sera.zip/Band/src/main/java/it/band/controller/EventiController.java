package it.band.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.band.service.ProductService;

@Controller
@RequestMapping("/eventi")
public class EventiController {

	@Autowired
	private ProductService productService;
	
	@GetMapping
	public String getPage(HttpSession session, Model model) {
		
		model.addAttribute("products", productService.getProducts());
		return "eventi";
	}
	@PostMapping("/search")
	public String search(@RequestParam("search") String search) {
		return "redirect:/shopSearch?search=" + search;
	}
}
