package it.band.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.band.dao.CustomerDao;
import it.band.model.Customer;

@Controller
@RequestMapping("/reservedCustomers")
public class ReservedCustomersController {
	
	@Autowired
	private CustomerDao customerDao;
	
	@GetMapping
	public String getPage(HttpSession session, Model model, @RequestParam(name = "id", required = false) Integer id) {
		if (session.getAttribute("username") == null) {
			return "redirect:/";
		}
		
		Customer customer = id == null ? new Customer() : customerDao.findById(id).get();
		
		model.addAttribute("customers", customerDao.findAll());
		model.addAttribute("username", session.getAttribute("username"));
		model.addAttribute("customer", customer);
		return "reservedCustomers";
	}
	
	@PostMapping
	public String editCustomer(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result) {
		if(result.hasErrors())
			return "reservedCustomers";
		customerDao.save(customer);
		return "redirect:/reservedCustomers";
	}
	
}
