package it.band.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.band.model.Product;
import it.band.service.ProductService;

@Controller
@RequestMapping("/detail")
public class DetailController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public String getPage(Model model, @RequestParam("id") Integer id) {
		Product product = productService.getProductById(id);
		model.addAttribute("product", product);
		return "detail";
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/addCart")
	public String addCart(@RequestParam("id") int id, HttpSession session) {
		
		List<Product> cart = null;
		if(session.getAttribute("cart") != null) {
			cart = (List<Product>) session.getAttribute("cart");
		} else {
			cart = new ArrayList<>();
		}
		cart.add(productService.getProductById(id));
		session.setAttribute("cart", cart);
		return "redirect:/detail?id=" + id;
	}
	@PostMapping("/search")
	public String search(@RequestParam("search") String search) {
		return "redirect:/shopSearch?search=" + search;
	}
}
