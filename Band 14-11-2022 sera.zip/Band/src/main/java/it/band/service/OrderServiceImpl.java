package it.band.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.band.dao.OrderDao;
import it.band.model.Order;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderDao orderDao;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ProductService productService;
	
	@Override
	public void registerOrder(Order order, Object... orderData) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			order.setDate(format.parse((String)orderData[0]));
		} catch (ParseException prs) {
			order.setDate(new Date());
		}
		
		order.setCustomer(customerService.getCustomerById(((int)orderData[1])));
		order.getProducts().clear();
		for(int i : (int[])orderData[2])
			order.getProducts().add(productService.getProductById(i));
		double totalPrice = order.getProducts()
				.stream()
				.map(a -> a.getPrice())
				.reduce(0.0, (a1, a2) -> a1 + a2);
		order.setTotalPrice(totalPrice);
		orderDao.save(order);
		
	}
	
	@Override
	public Order getOrderById(int id) {
		return orderDao.findById(id).get();
	}

	@Override
	public List<Order> getOrders() {
		return (List<Order>) orderDao.findAll();
	}

	@Override
	public void deleteOrder(Order order) {
		int idCustomer = order.getCustomer().getId();
		order.setCustomer(null);
		order.setProducts(null);
		orderDao.save(order);
		orderDao.delete(order);
		customerService.deleteCustomer(customerService.getCustomerById(idCustomer));
	}

	@Override
	public List<Integer> getProductsInOrder(int orderId) {
		return orderDao.getProductsInOrder(orderId);
	}

}