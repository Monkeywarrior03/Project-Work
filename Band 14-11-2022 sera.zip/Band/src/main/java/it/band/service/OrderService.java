package it.band.service;

import java.util.List;
import it.band.model.Order;

public interface OrderService {
	void registerOrder(Order order, Object... orderData);
	Order getOrderById(int id);
	List<Order> getOrders();
	void deleteOrder(Order order);
	List<Integer> getProductsInOrder(int orderId);
}
