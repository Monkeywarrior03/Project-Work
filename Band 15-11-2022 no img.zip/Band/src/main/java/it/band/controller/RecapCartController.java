package it.band.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.band.model.Product;

@Controller
@RequestMapping("/carrello")
public class RecapCartController {
	
	@SuppressWarnings("unchecked")
	@GetMapping
	public String getPage(Model model, HttpSession session) {
		if (session.getAttribute("cart") == null) {
			session.setAttribute("cart", new ArrayList<Product>());
		}
		
		model.addAttribute("cart", session.getAttribute("cart"));
		List<Product> cart = (List<Product>) session.getAttribute("cart");
		double totalPrice = 0;
		for (Product c : cart) {
			totalPrice += c.getPrice();
		}
		model.addAttribute("totalPrice", totalPrice);
		return "carrello";
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/removeFromCart")
	public String removeFromCart(@RequestParam("id") int id, HttpSession session) {
		List<Product> cart = (List<Product>) session.getAttribute("cart");
		cart.remove(id);
		session.setAttribute("cart", cart);
		return "redirect:/carrello";
	}
}
