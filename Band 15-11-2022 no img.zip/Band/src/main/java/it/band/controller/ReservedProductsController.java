package it.band.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.band.model.Product;
import it.band.service.ProductService;

@Controller
@RequestMapping("/reservedProducts")
public class ReservedProductsController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public String getPage(HttpSession session, Model model, @RequestParam(name = "id", required = false) Integer id, 
							@RequestParam(name = "fe", required = false) String fError,
							@RequestParam(name="si", required = false) String showImage) {
		
		if (session.getAttribute("username") == null) {
			return "redirect:/";
		}
		
		List<Product> products = productService.getProducts();
		for (int i = 0; i < products.size(); i++) {
			String filePath = session.getServletContext().getRealPath("/") + "static\\products\\" + products.get(i).getId() + ".png";
			File file = new File(filePath);
			products.get(i).setImage(file.exists());
		}
		
		boolean formError = fError == null ? false : true;
		Product product = id == null ? new Product() : productService.getProductById(id);
		
		model.addAttribute("products", products);
		model.addAttribute("product", product);
		model.addAttribute("formError", formError);
		model.addAttribute("showImage", showImage != null);
		model.addAttribute("fileName", id);
		return "reservedProducts";
	}
	
	@PostMapping
	public String editProduct(@Valid @ModelAttribute("product") Product product,
			BindingResult result) {
		
		if(result.hasErrors())
			return "reservedProducts";
		
		productService.createProduct(product, new Date().toString());
		
		int id;
		if (product.getId() == 0) {
			id = productService.getHighestId();
			return "redirect:/reservedProducts"; 
		} else {
			id = product.getId();
			return "redirect:/reservedProducts?id=" + id + "&si"; 
		}
		
	}
	
	@PostMapping("/editImage")
	public String editImage(@RequestParam(name = "fileName", required = false) String fileName, 
							@RequestParam(name = "image", required = false) MultipartFile image, 
							HttpSession session) {
		
		if(image != null && !image.isEmpty()) {
				saveImage(fileName, image, session);
		}
		
		return "redirect:/reservedProducts";
	}
	
	
	private void saveImage(String fileName, MultipartFile image, HttpSession session) {
		String filePath = session.getServletContext().getRealPath("/") + "static\\products\\" + fileName + ".png";
		try {
			image.transferTo(new File(filePath));
			productService.getProductById(Integer.parseInt(fileName)).setImage(true);
		} catch(IllegalStateException | IOException e) {
			e.printStackTrace(); 
			}
		}
}