package it.band.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "products")
public class Product implements Serializable{
	private static final long serialVersionUID = 2750801452613235880L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "name", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z'\\sàèìòù]{1,255}", message = "{error.charnotallowed}")
	private String name;
	
	@Column(name = "description", length = 4000, nullable = false)
	@Pattern(regexp = "[a-zA-Z'\\s@,;.-àèìòù]{1,4000}", message = "{error.charnotallowed}")
	private String description;
	
	@Digits(integer = 4, fraction = 2, message = "{error.invalidamount}")
	@Column(name = "price", nullable = false)
	private double price;
	
	@Column(name = "date", nullable = true)
	@DateTimeFormat(pattern = "yyyy-MM-dd") //molto utile con il form thymeleaf
	private Date date;
	
	@Digits(integer = 1, fraction = 0, message = "{error.invalidamount}")
	@Column(name = "type", nullable = false)
	private int type;
	
	@Digits(integer = 1, fraction = 0, message = "{error.invalidamount}")
	@Column(name = "available", nullable = false)
	private int available;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable (name = "products_sold", 
				joinColumns = @JoinColumn(name = "id_product", referencedColumnName = "id"),
				inverseJoinColumns = @JoinColumn(name = "id_order", referencedColumnName = "id"))
	private List<Order> orders = new ArrayList<>();
	
	@Transient
	private boolean included; //da togliere quando miglioro il reservedProduct
	
	@Transient 
	private boolean image;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public int getAvailable() {
		return available;
	}

	public void setAvailable(int available) {
		this.available = available;
	}

	public void setType(int type) {
		this.type = type;
	}

	public boolean isIncluded() {
		return included;
	}

	public void setIncluded(boolean included) {
		this.included = included;
	}

	public int getType() {
		return type;
	}

	public boolean isImage() {
		return image;
	}

	public void setImage(boolean image) {
		this.image = image;
	}
}