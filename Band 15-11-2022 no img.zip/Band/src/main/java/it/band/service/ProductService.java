package it.band.service;

import java.util.List;

import it.band.model.Product;

public interface ProductService {
	List <Product> getProducts();
	void createProduct(Product product, String date);
	Product getProductById(int id);
	void updateProduct(Product product);
	void deleteProduct(Product product);
	int getHighestId();
	List<Product> searchProducts(String search);
}