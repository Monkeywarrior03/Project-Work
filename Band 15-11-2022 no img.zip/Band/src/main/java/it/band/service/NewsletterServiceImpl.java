package it.band.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.band.dao.NewsletterDao;
import it.band.model.Newsletter;

@Service
public class NewsletterServiceImpl implements NewsletterService{

	@Autowired
	private NewsletterDao newsletterDao;
	
	@Override
	public void registerNewsletter(Newsletter newsletter) {
		newsletterDao.save(newsletter);
	}

	@Override
	public Newsletter getNewsletterById(int id) {
		return newsletterDao.findById(id).get();
	}

	@Override
	public List<Newsletter> getNewsletter() {
		return (List<Newsletter>) newsletterDao.findAll();
	}

	@Override
	public void deleteNewsletter(Newsletter newsletter) {
		newsletterDao.delete(newsletter);
	}

	@Override
	public int searchNewsletter(String search) {
		List<Newsletter> newsletters = (List<Newsletter>) newsletterDao.findAll();
		int newsletterId = 0;
		for (int i = 0; i < newsletters.size(); i++) {
			if (search.toLowerCase().equals(newsletters.get(i).getEmail().toLowerCase())) {
				newsletterId = newsletters.get(i).getId();
				break;
			}
		}
		return newsletterId;
	}

}
