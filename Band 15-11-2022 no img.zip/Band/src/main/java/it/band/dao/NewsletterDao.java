package it.band.dao;

import org.springframework.data.repository.CrudRepository;
import it.band.model.Newsletter;

public interface NewsletterDao extends CrudRepository<Newsletter, Integer>{

}
