package it.band.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "customers")
public class Customer implements Serializable{

	private static final long serialVersionUID = 8095907769980404457L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "name", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z'\\s]{1,255}", message = "{error.charnotallowed}")
	private String name;
	
	@Column(name = "surname", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z'\\s]{1,255}", message = "{error.charnotallowed}")
	private String surname;
	
	@Column(name = "address", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z\\s.']{1,255}", message = "{error.charnotallowed}")
	private String address;
	
	@Column(name = "civic_number", length = 10, nullable = false)
	@Pattern(regexp = "[0-9A-Z\\s.'-]{1,10}", message = "{error.charnotallowed}")
	private String civicNumber;
	
	@Column(name = "town", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z\\s.'-]{1,255}", message = "{error.charnotallowed}")
	private String town;
	
	@Column(name = "province", length = 2, nullable = false)
	@Pattern(regexp = "[A-Z]{2}", message = "{error.charnotallowed}")
	private String province;
	
	@Column(name = "postal_code", length = 5, nullable = false)
	@Pattern(regexp = "[0-9]{1,5}", message = "{error.charnotallowed}")
	private String postalCode;
	
	@Column(name = "telephone", length = 20, nullable = false)
	@Pattern(regexp = "[0-9\\s+]{1,20}", message = "{error.charnotallowed}")
	private String telephone;
	
	@Column(name = "email", length = 255, nullable = false)
	@Pattern(regexp = "[a-zA-Z0-9.@]{1,255}", message = "{error.charnotallowed}")
	private String email;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, 
			orphanRemoval = true, fetch = FetchType.EAGER)
	private List<Order> orders = new ArrayList<>();
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCivicNumber() {
		return civicNumber;
	}

	public void setCivicNumber(String civicNumber) {
		this.civicNumber = civicNumber;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
