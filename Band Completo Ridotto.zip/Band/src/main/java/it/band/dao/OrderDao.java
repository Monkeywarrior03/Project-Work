package it.band.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import it.band.model.Order;

public interface OrderDao extends CrudRepository<Order, Integer>{
	
	@Query (value = "SELECT id_product FROM products_sold WHERE id_order = :orderId", nativeQuery = true)
	public List<Integer> getProductsInOrder(@Param(value = "orderId") int orderId);
}