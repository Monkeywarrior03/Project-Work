package it.band.controller;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.band.dao.AdminDao;
import it.band.model.Admin;
import it.band.model.Newsletter;
import it.band.service.NewsletterService;

@Controller
@RequestMapping(path = { "/", "/index", "/home" })
public class IndexController {
	
	@Autowired
	private NewsletterService newsletterService;

	@Autowired
	private AdminDao adminDao;

	@GetMapping
	public String getPage(@RequestParam(name = "exists", required = false) String exists,
						  @RequestParam(name = "success", required = false) String success,
							Model model) {
		if (success != null) {
			model.addAttribute("exists", false);
			model.addAttribute("success", true);
			
		} else if (exists != null){
			model.addAttribute("exists", true);
			model.addAttribute("success", false);
			
		} else {
			model.addAttribute("exists", false);
			model.addAttribute("success", false);
		}
		return "index";
	}

	@PostMapping("/login")
	public String adminLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			HttpSession session) {
		List<Admin> admins = (List<Admin>) adminDao.findAll();
		boolean exists = false;
		for (int i = 0; i < admins.size(); i++) {
			if (admins.get(i).getUsername().equals(username) && admins.get(i).getPassword().equals(password)) {
				session.setAttribute("username", username);
				exists = true;
				break;
			}
		}

		if (exists) {
			return "redirect:/reservedCustomers";
		} else {
			return "redirect:/";
		}
	}

	@PostMapping("/search")
	public String search(@RequestParam("search") String search) {
		return "redirect:/shopSearch?search=" + search;
	}
	
	@PostMapping("/newsletter")
	public String newsletter(@RequestParam("email") String email) {
		int id = newsletterService.searchNewsletter(email);
		
		if (id == 0) {
			Newsletter newsletter = new Newsletter();
			newsletter.setEmail(email);
			newsletterService.registerNewsletter(newsletter);
			return "redirect:/index?success";
		} else {
			return "redirect:/index?exists";
		}
		
	}
}














