package it.band.controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.band.model.Customer;
import it.band.model.Order;
import it.band.model.Product;
import it.band.service.CustomerService;
import it.band.service.OrderService;
import it.band.service.ProductService;

@Controller
@RequestMapping("/reservedOrders")
public class ReservedOrdersController {
	
	private Order order;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private OrderService orderService;
	
	@SuppressWarnings("unchecked")
	@GetMapping
	public String getPage(
			Model model,
			@RequestParam(name = "id", required = false) Integer id, HttpSession session,
			@RequestParam(name="prEx", required = false) String prEx)
	{
		if (session.getAttribute("username") == null) {
			return "redirect:/";
		}
		
		
		order = id == null ? new Order() : orderService.getOrderById(id);
		List<Customer> customers = (List<Customer>) customerService.getCustomers();
		List<Product> products = productService.getProducts();
		if(order.getId() != 0)
			for(Product p : products)
				for(Product op : order.getProducts())
					if(p.getId() == op.getId())
						p.setIncluded(true);
		model.addAttribute("order", order);
		model.addAttribute("orders", orderService.getOrders());
		model.addAttribute("customers", customers);
		model.addAttribute("products", products);
		model.addAttribute("prEx", prEx!=null);
		model.addAttribute("editableOrder", (Order)session.getAttribute("editableOrder"));
		model.addAttribute("productsInOrder", (ArrayList<Product>)session.getAttribute("productsInOrder"));
		model.addAttribute("allProducts", productService.getProducts());
		return "reservedOrders";
	}
	
	@GetMapping("/editOrder")
	public String editOrder(@RequestParam("id") Integer id, HttpSession session) {
		session.setAttribute("editableOrder", orderService.getOrderById(id));
		List<Integer> listaIdProdotti = orderService.getProductsInOrder(id);
		ArrayList<Product> prodottiInOrdine = new ArrayList<>();
		for (int l : listaIdProdotti) {
			prodottiInOrdine.add(productService.getProductById(l));
		}
		session.setAttribute("productsInOrder", prodottiInOrdine);
		return "redirect:/reservedOrders?prEx";
	}
	
	@GetMapping("/removeFromOrder")
	public String removeFromOrder(@RequestParam("order") Integer idOrdine, @RequestParam("re") int idProdotto, HttpSession session) {
		
		List<Integer> listaIdProdotti = orderService.getProductsInOrder(idOrdine); //lista di tutti gli id
		for (int i = 0; i < listaIdProdotti.size(); i++) {
			if (listaIdProdotti.get(i) == idProdotto) {
				listaIdProdotti.remove(i);
				break;
			}
		}
		
		ArrayList<Product> prodottiInOrdine = new ArrayList<>();
	    for (int i = 0; i < listaIdProdotti.size(); i++) {
	    	prodottiInOrdine.add(productService.getProductById(listaIdProdotti.get(i)));
	    } //creo lista di prodotti aggiornata
		
	    int[] arrayIdProdotti = listaIdProdotti
	    									.stream()
	    										.mapToInt(i->i)
	    											.toArray();
	    
		session.setAttribute("productsInOrder", prodottiInOrdine);
		orderService.registerOrder(orderService.getOrderById(idOrdine), 
									orderService.getOrderById(idOrdine).getDate().toString(), 
									orderService.getOrderById(idOrdine).getCustomer().getId(),
									arrayIdProdotti);
		return "redirect:/reservedOrders?prEx";
	}
	
	@GetMapping("/addToOrder")
	public String addToOrder(@RequestParam("order") Integer idOrdine, @RequestParam("add") int idProdotto, HttpSession session) {
		List<Integer> listaIdProdotti = orderService.getProductsInOrder(idOrdine);
		listaIdProdotti.add(idProdotto);
		
		ArrayList<Product> prodottiInOrdine = new ArrayList<>();
	    for (int i = 0; i < listaIdProdotti.size(); i++) {
	    	prodottiInOrdine.add(productService.getProductById(listaIdProdotti.get(i)));
	    }
		
		int[] arrayIdProdotti = listaIdProdotti
				.stream()
					.mapToInt(i->i)
						.toArray();
		
		orderService.registerOrder(orderService.getOrderById(idOrdine), 
				orderService.getOrderById(idOrdine).getDate().toString(), 
				orderService.getOrderById(idOrdine).getCustomer().getId(),
				arrayIdProdotti);
		session.setAttribute("productsInOrder", prodottiInOrdine);
		return "redirect:/reservedOrders?prEx";
	}
}