package it.band.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.band.model.Product;
import it.band.service.ProductService;

@Controller
@RequestMapping("/shop")
public class ShopDisksController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public String getPage(HttpSession session, Model model) {
		List<Product> products = productService.getProducts();
		for (int i = 0; i < products.size(); i++) {
			String filePath = session.getServletContext().getRealPath("/") + "static\\products\\" + products.get(i).getId() + ".png";
			File file = new File(filePath);
			products.get(i).setImage(file.exists());
		}
		
		model.addAttribute("products", products);
		return "shop";
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/addCart")
	public String addCart(@RequestParam("id") int id, HttpSession session) {
		
		List<Product> cart = null;
		if(session.getAttribute("cart") != null) {
			cart = (List<Product>) session.getAttribute("cart");
		} else {
			cart = new ArrayList<>();
		}
		cart.add(productService.getProductById(id));
		session.setAttribute("cart", cart);
		return "redirect:/shop";
	}
}
