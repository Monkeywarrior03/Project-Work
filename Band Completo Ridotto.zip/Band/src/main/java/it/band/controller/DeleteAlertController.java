package it.band.controller;

import java.io.File;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.band.helper.DeletableItem;
import it.band.model.Product;
import it.band.service.CustomerService;
import it.band.service.OrderService;
import it.band.service.ProductService;
import it.band.model.Order;
import it.band.model.Customer;

@Controller
@RequestMapping("/deleteConfirm")
public class DeleteAlertController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private OrderService orderService;
	
	private DeletableItem deletableItem;
	
	@GetMapping
	public String getPage(Model model, @RequestParam("id") int id, @RequestParam("type") String type) {
		setDeletableItem(id, type);
		model.addAttribute("deletableItem", deletableItem);
		return "deleteAlert";
	}
	
	private void setDeletableItem(int id, String type) {
		switch(type) {
			case "product":
				Product product = productService.getProductById(id);
				deletableItem = new DeletableItem(id, type, product.getDescription(), "/reservedProducts");
				break;
			case "customer":
				Customer customer = customerService.getCustomerById(id);
				deletableItem = new DeletableItem(id, type, customer.getSurname(), "/reservedCustomers");
				break;
			case "order":
				Order order = orderService.getOrderById(id);
				deletableItem = new DeletableItem(id, type, "Ordine numero " + order.getId() + " - Cliente " + order.getCustomer().getSurname(), "/reservedOrders");
		}
	}
	
	@GetMapping("/deleteItem")
	public String deleteItem(HttpSession session) {
		switch(deletableItem.getType()) {
			case "product":
				Product product = productService.getProductById(deletableItem.getId());
				productService.deleteProduct(product);
				String filePath = session.getServletContext().getRealPath("/") + "static\\products\\" + product.getId() + ".png";
				File file = new File(filePath);
				file.delete();
				break;
			case "customer":
				customerService.deleteCustomer(customerService.getCustomerById(deletableItem.getId()));
				break;
			case "order":
				orderService.deleteOrder(orderService.getOrderById(deletableItem.getId()));
				break;
		}
		return "redirect:" + deletableItem.getRedirect();
	}
	
	@PostMapping("/search")
	public String search(@RequestParam("search") String search) {
		return "redirect:/shopSearch?search=" + search;
	}
}