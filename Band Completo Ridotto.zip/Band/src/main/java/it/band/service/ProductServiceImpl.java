package it.band.service;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.band.dao.ProductDao;
import it.band.model.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDao productDao;

	@Override
	public List<Product> getProducts() { 
		return (List<Product>) productDao.findAll();
	}

	@Override
	public void createProduct(Product product, String date) {
		productDao.save(product);
	}

	@Override
	public Product getProductById(int id) {
		return productDao.findById(id).get();
	}

	@Override
	public void updateProduct(Product product) {
		productDao.save(product);
	}

	@Override
	public void deleteProduct(Product product) {
		productDao.delete(product);
	}

	@Override
	public int getHighestId() {
		return productDao.getHighestId();
	}
	
	@Override
	public List<Product> searchProducts(String search) {
		List<Product> products = (List<Product>) productDao.findAll();
		products = products
					.stream()
					.filter(p -> p.getName().toLowerCase().contains(search.toLowerCase()))
					.collect(Collectors.toList());
		return products;
	}

}