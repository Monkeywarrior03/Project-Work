package it.band.service;

import java.util.List;

import it.band.model.Customer;


public interface CustomerService {
	void registerCustomer(Customer customer);
	Customer getCustomerById(int id);
	List<Customer> getCustomers();
	void deleteCustomer(Customer customer);
}
