package it.band.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.band.dao.CustomerDao;
import it.band.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public void registerCustomer(Customer customer) {
		customerDao.save(customer);
	}

	@Override
	public Customer getCustomerById(int id) {
		return customerDao.findById(id).get();
	}

	@Override
	public List<Customer> getCustomers() {
		return (List<Customer>) customerDao.findAll();
	}

	@Override
	public void deleteCustomer(Customer customer) {
		customerDao.delete(customer);
	}

}
