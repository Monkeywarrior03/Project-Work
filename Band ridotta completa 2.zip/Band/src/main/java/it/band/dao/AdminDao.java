package it.band.dao;

import org.springframework.data.repository.CrudRepository;
import it.band.model.Admin;

public interface AdminDao extends CrudRepository<Admin, Integer>{
	
}
