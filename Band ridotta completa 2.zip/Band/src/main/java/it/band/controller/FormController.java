package it.band.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.band.model.Customer;
import it.band.model.Order;
import it.band.model.Product;
import it.band.service.CustomerService;
import it.band.service.OrderService;

@Controller
@RequestMapping("/form")
public class FormController {
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping
	public String getPage(Model model, @RequestParam(name = "id", required = false) Integer id) {
		Customer customer = id == null ? new Customer() : customerService.getCustomerById(id);
		model.addAttribute("customer", customer);
		model.addAttribute("customers", customerService.getCustomers());
		return "form";
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping
	public String registerCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult result, HttpSession session) {
		if(result.hasErrors()) {
			return "form";
		}
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dataOdierna = format.format(new Date());
		
		customerService.registerCustomer(customer);
		List<Product> cart = (List<Product>) session.getAttribute("cart");
		
		int[] listaId = new int[cart.size()];
		for (int i = 0; i < cart.size(); i++) {
			listaId[i] = cart.get(i).getId();
		}
		
		orderService.registerOrder(new Order(), dataOdierna, customer.getId(), listaId);
		
		session.setAttribute("cart", null);
		return "wait";
	}
}
